/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant.neuer.versuch;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.*;
import javax.swing.border.LineBorder;
import javax.swing.JList;
import javax.swing.*;

/**
 *
 * @author Max Demel, Thomas Weber
 */
public class Oberflaeche {
    
    private Restaurant r;
    private JFrame f1;
    private JList<String[]> jl1;
    private JList<String[]> jl2;
    private JList<String[]> jl3;
    private JLabel l1;
    private JLabel l2;
    private JLabel l3;
    private JButton b1;
    private JButton[] b;
    private JPanel p1;
    private boolean manSt;
    private int turns;
    
    public Oberflaeche(Restaurant rs) {
        
        //Restaurant speichern
        r = rs;
        
        //neues Fenster
        f1 = new JFrame("Restaurant Simulation");
        f1.setVisible(true);
        f1.setBounds(500,500,1520,1555);
            
        //neue Textfelder
        jl1= new JList(r.besetzteStuehleGeben());
        jl2= new JList(r.bestellungenInBearbeitungGeben());
        l1= new JLabel();
        l2= new JLabel();
        l3 = new JLabel();
        
        //Texte setzen
        l1.setText("Bruttoeinnahmen des " + r.tagesAnzahlGeben() + ". Tages: " + r.tagesEinnahmenGeben() + "€");
        l2.setText("Bruttoeinnahmen von " + r.tagesAnzahlGeben() + " Tag(en): " + r.gesamtEinnahmenGeben() + "€");
        
        //neue Knöpfe
        b1= new JButton("Inhalt Bestellungen Anzeigen");
        b = new JButton[r.tischzahlGeben()];
       
        
        //neuer Layoutmanager
        p1= new JPanel();
        p1.setLayout(null);

        //verknüpfen der Elemente
        f1.add(p1);
        p1.add(jl1);
        p1.add(jl2);
        p1.add(l1);
        p1.add(l2);
        p1.add(l3);
        p1.add(b1);
        
        //Knöpfe für manuelle Steuerung
        
        for(int i = 0; i<b.length; i++) {
            b[i] = new JButton("Tisch " + r.tischGeben(i).tischNummerGeben());
            p1.add(b[i]);
            if (i%2==0) {
                b[i].setBounds((i/2*300), 0, 290, 320);
            } else {
                b[i].setBounds(((i-1)/2*300), 330, 290, 320);
            }
            b[i].setBackground(Color.GRAY);
            b[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    switch(r.tischGeben(i).bestelltGeben()){
                        case 0:
                            r.kundenKommenManuell(r.tischGeben(i));
                            b[i].setBackground(Color.RED);
                            l3.setText("Kunden haben sich an Tisch 10 gesetzt!");
                            break;
                        case 1:
                            r.bestellungErstellen(i);
                            b[i].setBackground(Color.ORANGE);
                            l3.setText("Tisch 10 hat eine Bestellung aufgegeben!");
                            break;
                        case 2:
                            r.bearbeiteBestellungManuell(r.tischGeben(i));
                            b[i].setBackground(Color.GREEN);
                            l3.setText("Die Bestellung von Tisch 10 wurde bearbeitet!");
                            break;
                        case 3:
                            r.tischGeben(i).gaesteGehen();
                            b[i].setBackground(Color.GRAY);
                            l3.setText("Die Kunden von Tisch 10 sind gegangen!");
                            break;
                    }
                    turns++;
                }
            });
        }      
         
        //farbe setzen
        b1.setBackground(Color.GRAY);
        
        //Positionen festlegen
        b1.setBounds(0,750,375,375);
        jl1.setBounds(375,750,375,750);
        jl2.setBounds(750,750,375,375);
        l1.setBounds(1125,750,375,375);
        l2.setBounds(1125, 1125, 375,375);
        l3.setBounds(750, 1125, 375, 375);
        
        //Rahmenlinien festlegen
        jl1.setBorder(new LineBorder(Color.BLACK));
        jl2.setBorder(new LineBorder(Color.BLACK));
        l1.setBorder(new LineBorder(Color.BLACK));
        l2.setBorder(new LineBorder(Color.BLACK));
        l3.setBorder(new LineBorder(Color.BLACK));
        
        //Knopffunktionen setzen
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int i = Integer.parseInt(JOptionPane.showInputDialog("Geben Sie die nummer des Tisches, welcher die Bestellung aufgegeben hat an: "));
                if(i <= r.tischzahlGeben() && r.tischGeben(i-1).bestelltGeben() == 2){
                    jl3 = new JList(r.unbearbeiteteBestellungsinhalteGeben(i));
                    p1.add(jl3);
                    jl3.setBounds(0,1125,375,375);
                    jl3.setBorder(new LineBorder(Color.BLACK));
                } else {
                    JOptionPane.showMessageDialog(null, "Die Tischnummer oder die Bestellung existieren nicht!");
                }
                
            }
        });
        
        f1.setDefaultCloseOperation(f1.EXIT_ON_CLOSE);
    }
    
    public void aktuallisieren() {
        jl1.setVisible(false);
        jl1= new JList(r.besetzteStuehleGeben());
        jl1.setBounds(375,750,375,750);
        jl1.setBorder(new LineBorder(Color.BLACK));
        jl2.setVisible(false);
        jl2= new JList(r.bestellungenInBearbeitungGeben());
        jl2.setBounds(750,750,375,750);
        jl2.setBorder(new LineBorder(Color.BLACK));
        l1.setText("Bruttoeinnahmen des " + r.tagesAnzahlGeben() + ". Tages: " + r.tagesEinnahmenGeben() + "€");
        l2.setText("Bruttoeinnahmen von " + r.tagesAnzahlGeben() + " Tag(en): " + r.gesamtEinnahmenGeben() + "€");
        
        for(int i = 0; i<r.tischzahlGeben(); i++) {
            switch(r.tischGeben(i).bestelltGeben()){
                case 0:
                    b[i].setBackground(Color.GRAY);
                    break;
                case 1:
                    b[i].setBackground(Color.RED);
                    break;
                case 2:
                    b[i].setBackground(Color.ORANGE);
                    break;
                case 3:
                    b[i].setBackground(Color.GREEN);
                    break;    
            }
        }
        
        p1.add(jl1);
        p1.add(jl2);
        p1.add(l1);
        p1.add(l2);
        
        p1.repaint();
    }
    
    public int turnsGeben() {
        return turns;
    }
    
}
